﻿public Class Unload;
{
    public static int GetUnloadOption(ByVal dummy As String)
    {
        int unloadOption;

        unloadOption = NXOpen.Session.LibraryUnloadOption.Immediately;       //After executing
        //unloadOption = NXOpen.Session.LibraryUnloadOption.AtTermination     //When NX session terminates
        //unloadOption = NXOpen.Session.LibraryUnloadOption.Explicitly        //Using File-->Unload

        return unloadOption;

    }

}
