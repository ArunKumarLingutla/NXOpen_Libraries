using NXOpen;
public class MyProgram
{
    public static void Main()
    {
        Session theSession = Session.GetSession();

        //Your code goes here

    }

}


