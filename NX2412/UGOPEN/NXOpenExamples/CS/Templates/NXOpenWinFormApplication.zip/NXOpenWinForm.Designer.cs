﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
partial class NXOpenWinForm
{
   Inherits System.Windows.Forms.Form

   public static void New()
   {
      InitializeComponent();
      NXOpenUI.FormUtilities.SetApplicationIcon(this);
      NXOpenUI.FormUtilities.ReparentForm(this);
   }

   //Form overrides dispose to clean up the component list.
   ///////<System.Diagnostics.DebuggerNonUserCode()> _
   protected override void Dispose(bool disposing)
   {
      try
      {
         if (disposing != null && components != null)
         {
            components.Dispose()
         }
      }
      finally
      {
         MyBase.Dispose(disposing)
      }
   }

   //Required by the Windows Form Designer
   private System.ComponentModel.IContainer components;

   //NOTE: The following procedure is required by the Windows Form Designer
   //It can be modified using the Windows Form Designer.  
   //Do not modify it using the code editor.
   ///////<System.Diagnostics.DebuggerStepThrough()> _
   private void InitializeComponent()
   {
      this.SuspendLayout()
      //
      //SnapWinForm
      //
      this.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = New System.Drawing.Size(275, 142);
      this.Name = "NXOpenWinForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "NX Open WinForm";
      this.ResumeLayout(False);
   }
}
