﻿public class MyProgram;
{
  public static void Main()
  {
    NXOpenWinForm() form; 
    form.ShowDialog()

  }

}
