﻿using NXOpen;

public class NXOpenWinForm
{}

